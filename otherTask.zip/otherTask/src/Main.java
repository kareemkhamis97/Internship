import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String args[]) {

        int numberOfUsers;

        Scanner sc = new Scanner(System.in);
        ArrayList<User> users = new ArrayList<>();
        ArrayList<User> userSearch = new ArrayList<>();
        String name;
        String surname;
        String dateOfBirth;
        int counter = 1;
        String search;

        System.out.println("Enter number of users you want to work with: ");
        numberOfUsers = sc.nextInt();

        for (int i = 0; i < numberOfUsers; i++) {


            System.out.println("Enter user " + counter + " name: ");
            name = sc.next();
            System.out.println("Enter user " + counter + " surname: ");
            surname = sc.next();
            System.out.println("Enter user " + counter + " date of birth: ");
            dateOfBirth = sc.next();
            counter += 1;
            System.out.println("***************************");
            users.add(new User(name, surname, dateOfBirth));

        }


        while (true) {

            System.out.println("1. Show all");
            System.out.println("2. Show data about oldest user ");
            System.out.println("3. Sort Users by Date of birth");
            System.out.println("4. Search by Name or Surname");
            System.out.println("5. Add new ");

            int choice;

            System.out.println("Enter your choice: ");
            choice = sc.nextInt();
            switch (choice) {

                case 1:
                	
                    for (User user : users) {
                    	 
                        System.out.println(user.getName() + " " + user.getSurname());
                        System.out.println("***************************");
                    }
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    System.out.println("Enter user name or user surname");
                    search = sc.next();

          for (User user:users){

              if (user.getName().equals(search) || user.getSurname().equals(search)){
                  userSearch.add(new User(user.name,user.getSurname(),user.getDateOfBirth()));
                  System.out.println(user.getName()+" "+user.getSurname());
                  break;
              }

          }

if (userSearch.isEmpty()){
    System.out.println("No user ");
}
                    break;

                case 5:

                    System.out.println("Enter user name: ");
                    name = sc.next();
                    System.out.println("Enter user surname: ");
                    surname = sc.next();
                    System.out.println("Enter user date of birth: ");
                    dateOfBirth = sc.next();

                    users.add(new User(name, surname, dateOfBirth));
                    for (User user : users) {
                        System.out.println(user.getName() + " " + user.getSurname());
                    }
                    break;

            }


        }
    }

}
