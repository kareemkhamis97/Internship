package com.example.myproject;
import static androidx.navigation.fragment.FragmentKt.findNavController;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

public class StartFragment extends Fragment {
    public StartFragment(){}
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        NavController navController;

        View rootView = inflater.inflate(R.layout.fragment_start, container, false);

//        Button fiveDays = rootView.findViewById(R.id.programOne);
//        Button threeDays = rootView.findViewById(R.id.fiveDaysFragment);
//        navController = Navigation.findNavController(rootView);

//
//            threeDays.setOnClickListener(new View.OnClickListener() {
//                public void onClick(View v) {
//            navController.navigate(R.id.action_startFragment_to_fiveDaysFragment);                }
//            });
//
//        fiveDays.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                navController.navigate(R.id.action_startFragment_to_fiveDaysFragment);                }
//        });
        return rootView;


    }}